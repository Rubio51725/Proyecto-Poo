import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static List<Usuario> usuarios = new ArrayList<>();
    private static Inventario inventario = new Inventario();

    public static void main(String[] args) {
        inicializarUsuarios();
        mostrarMenuPrincipal();
    }

    private static void inicializarUsuarios() {
        usuarios.add(new Cliente("cliente", "1234"));
        usuarios.add(new Empleado("empleado", "abcd"));
    }

    private static void mostrarMenuPrincipal() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Bienvenido al Sistema de Punto de Venta");
            System.out.println("1. Iniciar sesión");
            System.out.println("2. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    mostrarMenuInicioSesion();
                    break;
                case 2:
                    System.out.println("Gracias por usar el Sistema de Punto de Venta. ¡Hasta luego!");
                    System.exit(0);
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }
    }

    private static void mostrarMenuInicioSesion() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Menú de Inicio de Sesión");
            System.out.println("1. Cliente");
            System.out.println("2. Empleado");
            System.out.println("3. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    iniciarSesionCliente();
                    break;
                case 2:
                    iniciarSesionEmpleado();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }
    }

    private static void iniciarSesionCliente() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Usuario Cliente: ");
        String nombreUsuario = scanner.nextLine();
        System.out.print("Contraseña: ");
        String contrasena = scanner.nextLine();

        Usuario usuario = validarCredenciales(nombreUsuario, contrasena);

        if (usuario instanceof Cliente) {
            usuario.mostrarMenu();
        } else {
            System.out.println("Credenciales incorrectas para un cliente. Inténtelo de nuevo.");
        }
    }

    private static void iniciarSesionEmpleado() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Usuario Empleado: ");
        String nombreUsuario = scanner.nextLine();
        System.out.print("Contraseña: ");
        String contrasena = scanner.nextLine();

        Usuario usuario = validarCredenciales(nombreUsuario, contrasena);

        if (usuario instanceof Empleado) {
            usuario.mostrarMenu();
        } else {
            System.out.println("Credenciales incorrectas para un empleado. Inténtelo de nuevo.");
        }
    }

    private static Usuario validarCredenciales(String nombreUsuario, String contrasena) {
        return usuarios.stream()
                .filter(usuario -> usuario.validarCredenciales(nombreUsuario, contrasena))
                .findFirst()
                .orElse(null);
    }
}

abstract class Usuario {
    protected String nombre;
    protected String contrasena;

    public Usuario(String nombre, String contrasena) {
        this.nombre = nombre;
        this.contrasena = contrasena;
    }

    public abstract void mostrarMenu();

    public boolean validarCredenciales(String nombreUsuario, String contrasena) {
        return this.nombre.equals(nombreUsuario) && this.contrasena.equals(contrasena);
    }
}

class Cliente extends Usuario {
    private CarritoDeCompra carrito;
    private Inventario inventario;

    public Cliente(String nombre, String contrasena) {
        super(nombre, contrasena);
        this.carrito = new CarritoDeCompra();
        this.inventario = inventario;
    }

    @Override
    public void mostrarMenu() {
        carrito.mostrarMenu(inventario);
    }
}

class Empleado extends Usuario {
    public Empleado(String nombre, String contrasena) {
        super(nombre, contrasena);
    }

    @Override
    public void mostrarMenu() {
        Inventario.mostrarMenu();
    }
}

class Inventario {
    private static List<String> elementos = new ArrayList<>();

    public static void mostrarMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Menú de Inventario");
            System.out.println("1. Registrar elemento");
            System.out.println("2. Borrar elemento");
            System.out.println("3. Ordenar elementos");
            System.out.println("4. Mostrar elementos");
            System.out.println("5. Volver al menú anterior");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    registrarElemento();
                    break;
                case 2:
                    borrarElemento();
                    break;
                case 3:
                    ordenarElementos();
                    break;
                case 4:
                    mostrarElementos();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }
    }

    private static void registrarElemento() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el nombre del elemento a registrar: ");
        String elemento = scanner.nextLine();
        elementos.add(elemento);

        System.out.println("Elemento registrado exitosamente: " + elemento);
    }

    private static void borrarElemento() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el nombre del elemento a borrar: ");
        String elemento = scanner.nextLine();

        if (elementos.remove(elemento)) {
            System.out.println("Elemento borrado exitosamente: " + elemento);
        } else {
            System.out.println("Elemento no encontrado en el inventario.");
        }
    }

    private static void ordenarElementos() {
        Collections.sort(elementos);
        System.out.println("Elementos ordenados alfabéticamente.");
    }

    static void mostrarElementos() {
        System.out.println("Elementos en el inventario:");
        elementos.forEach(System.out::println);
    }

    public static boolean validarElementoEnInventario(String elemento) {
        return elementos.contains(elemento);
    }
}

class CarritoDeCompra {
    private List<String> elementos = new ArrayList<>();

    public void mostrarMenu(Inventario inventario) {
        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                System.out.println("Carrito de Compra");
                System.out.println("1. Visualizar elementos de inventario");
                System.out.println("2. Agregar elemento al carrito");
                System.out.println("3. Eliminar elemento del carrito");
                System.out.println("4. Mostrar elementos en el carrito");
                System.out.println("5. Realizar pago");
                System.out.println("6. Volver al menú anterior");
                System.out.print("Seleccione una opción: ");

                int opcion;
                try {
                    opcion = scanner.nextInt();
                    scanner.nextLine();
                } catch (java.util.InputMismatchException e) {
                    System.out.println("Por favor, ingrese un número válido.");
                    scanner.nextLine();
                    continue;
                }

                switch (opcion) {
                    case 1:
                        inventario.mostrarElementos();
                        break;
                    case 2:
                        agregarElemento(inventario);
                        break;
                    case 3:
                        eliminarElemento();
                        break;
                    case 4:
                        mostrarElementos();
                        break;
                    case 5:
                        realizarPago();
                        return;
                    case 6:
                        return;
                    default:
                        System.out.println("Opción no válida. Inténtelo de nuevo.");
                }
            }
        }
    }

    private void agregarElemento(Inventario inventario) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Ingrese el nombre del elemento a agregar al carrito: ");
            String elemento = scanner.nextLine();

            if (inventario.validarElementoEnInventario(elemento)) {
                elementos.add(elemento);
                System.out.println("Elemento agregado al carrito: " + elemento);
            } else {
                System.out.println("Elemento no encontrado en el inventario.");
            }
        }
    }

    private void eliminarElemento() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Ingrese el nombre del elemento a eliminar del carrito: ");
            String elemento = scanner.nextLine();

            if (elementos.remove(elemento)) {
                System.out.println("Elemento eliminado del carrito: " + elemento);
            } else {
                System.out.println("Elemento no encontrado en el carrito.");
            }
        }
    }

    private void mostrarElementos() {
        System.out.println("Elementos en el carrito de compra:");
        elementos.forEach(System.out::println);
    }

    private void realizarPago() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Contenido del carrito de compra:");
        mostrarElementos();

        double total = calcularTotal();
        System.out.println("Total a pagar: $" + total);

        System.out.print("¿Desea realizar el pago? (S/N): ");
        String respuesta = scanner.nextLine();

        if (respuesta.equalsIgnoreCase("S")) {
            System.out.println("Procesando el pago...");
            elementos.clear();
            System.out.println("Pago realizado con éxito. ¡Gracias por su compra!");
        } else {
            System.out.println("Pago cancelado. Los elementos en el carrito siguen ahí.");
        }
    }

    private double calcularTotal() {
        return elementos.size() * 10.0; // Precio ficticio por cada elemento
    }
}