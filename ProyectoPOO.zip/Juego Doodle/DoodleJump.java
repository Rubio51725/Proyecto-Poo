
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.sound.sampled.*;

class PosicionPlataforma {
    int x;
    int y;
}

public class DoodleJump<posicionesPlataformas> extends JPanel implements Runnable, KeyListener {

    private static String imagen = "dodle2.png";
    private static String imagenfondo = "Fondo1.jpg";
    private static String fondoMenu = "FondoMenu.png";
    private static String fondoSeleccionado;

    private static JFrame ventanaAnterior;
    final int Ancho = 1000;
    final int Alto = 700;

    boolean enEjecucion;
    Thread hilo;
    BufferedImage vista, fondo, plataforma, doodle;

    PosicionPlataforma[] posicionesPlataformas;
    int x = 400, y = 100, h = 100;
    float dy = 0;
    boolean derecha, izquierda;

    private int puntuacion;
    private Clip clip;
    private Clip salto;

    public DoodleJump() {
        setPreferredSize(new Dimension(Ancho, Alto));
        addKeyListener(this);
        setFocusable(true);
        puntuacion = 0;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame ventana = new JFrame("Menu Doodle Jump");

            DoodleJump juego = new DoodleJump();
            JLabel labelMensaje = new JLabel("Fondos");
            labelMensaje.setFont(new Font("Arial", Font.BOLD, 15));
            labelMensaje.setBounds(650, 15, 200, 50);
            ventana.add(labelMensaje);
            // Agregar el JLabel al panel
            ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JPanel panel = new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    ImageIcon fondo = new ImageIcon("FondoMenu.png");
                    g.drawImage(fondo.getImage(), 0, 0, getWidth(), getHeight(), this);
                }
            };
            panel.setLayout(null);
            JButton boton = new JButton("Play");
            JButton boton2 = new JButton("Change Player");
            JButton boton3 = new JButton(" ");
            JButton boton4 = new JButton(" ");
            boton.setContentAreaFilled(false);
            boton.setForeground(Color.BLACK);
            boton.setBounds(350, 185, 100, 50);

            boton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    SwingUtilities.invokeLater(() -> {
                        JFrame ventana = new JFrame("Juego");
                        ventana.setResizable(false);
                        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        DoodleJump juego = new DoodleJump();
                        juego.iniciarJuego();
                        ventana.add(juego);
                        ventana.pack();
                        ventana.setLocationRelativeTo(null);
                        ventana.setVisible(true);
                    });
                }
            });

            boton2.setContentAreaFilled(false);
            boton2.setForeground(Color.BLACK);
            boton2.setBounds(300, 100, 200, 50);
            boton2.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    juego.modificarVariable();
                    ImageIcon nuevaIcono = new ImageIcon(imagen);
                    boton2.setIcon(nuevaIcono);
                }
            });

            ImageIcon fprincipal = new ImageIcon("FondoT.jpg");

            boton3.setIcon(fprincipal);
            boton3.setContentAreaFilled(false);
            boton3.setForeground(Color.BLACK);
            boton3.setBounds(600, 65, 150, 150);
            boton3.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Abre un cuadro de diálogo para seleccionar un fondo
                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setCurrentDirectory(new File("."));

                    int result = fileChooser.showOpenDialog(null);

                    if (result == JFileChooser.APPROVE_OPTION) {
                        // Si se selecciona un archivo, establece ese archivo como fondo
                        imagenfondo = fileChooser.getSelectedFile().getPath();
                        fondoSeleccionado = imagenfondo;
                    } else {
                        // Si no se selecciona ninguno, establece el fondo predefinido
                        imagenfondo = fondoMenu;
                        fondoSeleccionado = null; // Indica que no se ha seleccionado ningún fondo
                    }
                }
            });

            panel.add(boton);
            panel.add(boton2);
            panel.add(boton3);
            ventana.getContentPane().add(panel);
            ventana.setSize(800, 400);
            ventana.setLocationRelativeTo(null);
            ventana.setVisible(true);
        });
    }

    private void cargarMusica() {
        try {
            String rutaMusica = "julia-133094.wav";
            File archivoMusica = new File(rutaMusica);
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(archivoMusica);
            clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.loop(Clip.LOOP_CONTINUOUSLY);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void musicaSalto() {
        try {
            String rutaMusica = "sonidoSalto.wav";
            File archivoMusica = new File(rutaMusica);
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(archivoMusica);
            salto = AudioSystem.getClip();
            salto.open(audioInputStream);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void start() {
        try {
            vista = new BufferedImage(Ancho, Alto, BufferedImage.TYPE_INT_RGB);
            if (fondoSeleccionado != null) {
                fondo = ImageIO.read(new File(fondoSeleccionado));
            } else {
                fondo = ImageIO.read(getClass().getResource("Fondo2.jpg"));
            }
            plataforma = ImageIO.read(getClass().getResource("plataforma.png"));
            doodle = ImageIO.read(getClass().getResource(imagen));

            posicionesPlataformas = new PosicionPlataforma[25];

            for (int i = 0; i < 25; i++) {
                posicionesPlataformas[i] = new PosicionPlataforma();
                posicionesPlataformas[i].x = new Random().nextInt(1000);
                posicionesPlataformas[i].y = new Random().nextInt(1113);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update() {
        if (derecha) {
            x += 3;
            if (x > Ancho) {
                x = -doodle.getWidth();
            }
        } else if (izquierda) {
            x -= 3;
            if (x < -doodle.getWidth()) {
                x = Ancho;
            }
        }

        dy += 0.2;
        y += dy;

        if (y > Alto) {
            enEjecucion = false;
            mostrarVentanaFin();
            return;
        }

        if (y < h) {
            for (int i = 0; i < 25; i++) {
                y = h;
                posicionesPlataformas[i].y = posicionesPlataformas[i].y - (int) dy;
                if (posicionesPlataformas[i].y > Alto) {
                    posicionesPlataformas[i].y = 0;
                    posicionesPlataformas[i].x = new Random().nextInt(Ancho);
                }
            }
        }

        for (int i = 0; i < 25; i++) {
            if ((x + 50 > posicionesPlataformas[i].x) &&
                    (x + 20 < posicionesPlataformas[i].x + 68) &&
                    (y + 70 > posicionesPlataformas[i].y) &&
                    (y + 70 < posicionesPlataformas[i].y + 14) &&
                    (dy > 0)) {
                dy = -10;
                puntuacion += 1;
                reproducirSonidoSalto();
            }
        }
    }

    private void reproducirSonidoSalto() {
        if (salto != null) {
            salto.setMicrosecondPosition(0);
            salto.start();
        }
    }

    public void draw() {
        Graphics2D g2 = (Graphics2D) vista.getGraphics();
        g2.drawImage(fondo, 0, 0, Ancho, Alto, this);
        g2.drawImage(doodle, x, y, doodle.getWidth(), doodle.getHeight(), this);
        for (int i = 0; i < 25; i++) {
            g2.drawImage(
                    plataforma,
                    posicionesPlataformas[i].x,
                    posicionesPlataformas[i].y,
                    plataforma.getWidth(),
                    plataforma.getHeight(),
                    null);
        }

        g2.setColor(Color.BLACK);
        g2.setFont(new Font("Arial", Font.BOLD, 20));
        g2.drawString("Puntuación: " + puntuacion, Ancho - 200, 30);

        Graphics g = getGraphics();
        g.drawImage(vista, 0, 0, Ancho, Alto, null);
        g.dispose();
    }

    public void cerrarVentana() {
        if (clip != null) {
            clip.stop();
        }

        JFrame ventana = (JFrame) SwingUtilities.getWindowAncestor(this);
        ventana.dispose();
    }

    public void mostrarVentanaFin() {
        cerrarVentana();
        JFrame ventanaFin = new JFrame("Fin del Juego");
        ventanaFin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panelFin = new JPanel();
        panelFin.setLayout(new BoxLayout(panelFin, BoxLayout.Y_AXIS));
        JLabel labelMensaje = new JLabel("¡Juego terminado!");
        labelMensaje.setFont(new Font("Arial", Font.BOLD, 20));
        labelMensaje.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel labelPuntuacion = new JLabel("Puntuacion: " + puntuacion);
        labelPuntuacion.setFont(new Font("Arial", Font.PLAIN, 16));
        labelPuntuacion.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton botonReiniciar = new JButton("Reiniciar Juego");
        botonReiniciar.setAlignmentX(Component.CENTER_ALIGNMENT);

        botonReiniciar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(() -> {
                    if (ventanaAnterior != null) {
                        ventanaAnterior.dispose();
                    }
                    JFrame ventana = new JFrame("Juego");
                    ventana.setResizable(false);
                    ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    DoodleJump juego = new DoodleJump();
                    juego.iniciarJuego();
                    ventana.add(juego);
                    ventana.pack();
                    ventana.setLocationRelativeTo(null);
                    ventana.setVisible(true);
                });
            }
        });

        panelFin.add(Box.createVerticalStrut(20));
        panelFin.add(labelMensaje);
        panelFin.add(Box.createVerticalStrut(10));
        panelFin.add(labelPuntuacion);
        panelFin.add(Box.createVerticalStrut(20));
        panelFin.add(botonReiniciar);

        ventanaFin.getContentPane().add(panelFin);
        ventanaFin.setSize(300, 200);
        ventanaFin.setLocationRelativeTo(null);
        ventanaFin.setVisible(true);
    }

    public void reiniciarJuego() {
        x = 400;
        y = 100;
        dy = 0;
        puntuacion = 0;
        enEjecucion = true;
        start();
    }

    @Override
    public void run() {
        try {
            requestFocus();
            start();
            while (enEjecucion) {
                update();
                draw();
                Thread.sleep(1000 / 60);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            derecha = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            izquierda = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            derecha = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            izquierda = false;
        }
    }

    public void modificarVariable() {
        imagen = "doodle.png";
    }

    public void iniciarJuego() {
        enEjecucion = true;
        hilo = new Thread(this);
        hilo.start();
        cargarMusica();
        musicaSalto();
        addKeyListener(this);
        requestFocusInWindow();
        addNotify();
    }
}
